<?php phpinfo(INFO_ALL) ?>
