<html>
	<head>
		<title>PHP test</title>
	</head>
	<body>
		<h3>Instructions</h3>
		<ul>
			<li>Saisisser une langue dans l'URI.<br/>Par exemple, pour le français : /php/test.php?lang=fr</li>
			<li>Rafraichissez la page</li>
			<li>La page dira si elle vous comprend :</li>
			<ul>
				<li>'fr' ou 'en' : compris</li>
				<li>autre : incompris</li>
			</ul>
		</ul>
		<h3>Result</h3>
		<?php
			$lang = $_GET['lang'];
			$is_lang_fr = $lang === 'fr';
			$is_lang_en = $lang === 'en';
			if ($is_lang_fr)
				echo 'Vous parlez français !';
			elseif ($is_lang_en)
				echo 'You speak English!';
			else
				echo 'Je ne vois pas quelle est votre langue !';
		?>
	</body>
</html>
